import { Component } from '@angular/core';
import { MsalService } from '@azure/msal-angular';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html'
})
export class AppComponent {
  title = 'app';

  public account: any;

  constructor(private authService: MsalService) {
    this.account = this.authService.getAccount();
  }

  public login() {
    this.authService.loginRedirect();

  }

  public logout() {
    this.authService.logout();
    // this.authService.loginRedirect();

    // this.account = null;

  }

}

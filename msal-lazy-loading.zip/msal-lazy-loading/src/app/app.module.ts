import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { RouterModule } from '@angular/router';

import { AppComponent } from './app.component';
import { NavMenuComponent } from './nav-menu/nav-menu.component';
import { HomeComponent } from './home/home.component';
import { CounterComponent } from './counter/counter.component';
import { FetchDataComponent } from './fetch-data/fetch-data.component';
import { MsalModule, MsalInterceptor } from '@azure/msal-angular';
import { AppRouteModule } from './app-route.module';

@NgModule({
  declarations: [
    AppComponent,
    NavMenuComponent,
    HomeComponent,
    CounterComponent,
    FetchDataComponent
  ],
  imports: [
    BrowserModule.withServerTransition({ appId: 'ng-cli-universal' }),
    HttpClientModule,
    FormsModule,
    AppRouteModule,
    RouterModule.forRoot([
      { path: '', component: HomeComponent, pathMatch: 'full' },
      { path: 'counter', component: CounterComponent },
      { path: 'fetch-data', component: FetchDataComponent },
    ]),
    MsalModule.forRoot({
      auth: {
        clientId: 'a4e93bab-ee17-4e46-a13c-4cfc3f5069dc',//'638c5af4-6b31-4561-b0a6-7498f9638d69',//'a4e93bab-ee17-4e46-a13c-4cfc3f5069dc',
        // authority: 'https://login.microsoftonline.com/common/',
        //76a297fb-ac22-45f9-bc91-2ec86525d94d
        authority: "https://login.microsoftonline.com/76a297fb-ac22-45f9-bc91-2ec86525d94d",
        validateAuthority: true,
        redirectUri: 'http://localhost:4200/',
        postLogoutRedirectUri: 'http://localhost:4200/',
        navigateToLoginRequestUrl: true,
      },
      cache: {
        cacheLocation: 'localStorage',
        storeAuthStateInCookie: false, // set to true for IE 11
      },
    },
    // {
    //   popUp: false,
    //   consentScopes: [
    //     'user.read',
    //     'openid',
    //     'profile',
    //     'api://a88bb933-319c-41b5-9f04-eff36d985612/access_as_user'
    //   ],
    //   unprotectedResources: ['https://www.microsoft.com/en-us/'],
    //   protectedResourceMap,
    //   extraQueryParameters: {}
    // }
    )
  ],
  providers: [
    {
      provide: HTTP_INTERCEPTORS,
      useClass: MsalInterceptor,
      multi: true
    }
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }

import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ProductComponent } from './product/product.component';
import { ProductRouteModule } from './product-route.module';



@NgModule({
  declarations: [ProductComponent],
  imports: [
    CommonModule,
    ProductRouteModule
  ]
})
export class ProductModule { }

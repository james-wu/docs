https://www.c-sharpcorner.com/article/easily-enable-azure-ad-authentication-in-angular-and-web-api-core-app/

https://stackblitz.com/angular/eydbdkevjmb?file=src%2Fapp%2Fapp.component.html

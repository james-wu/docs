﻿using System;
using System.Linq.Expressions;
using Validation.Models;

namespace Validation.Specifications
{
    public class CorrelationIdMatchSpecification : RuleSpecification<CorrelationIdMatch>
    {
        public CorrelationIdMatchSpecification(CorrelationIdMatch ruleDefinitionContext) : base(ruleDefinitionContext) { }

        public override Expression<Func<CorrelationIdMatch, bool>> IsSatisfiedBy =>
            context => context.ActualCorrelationId != null &&
                       string.Equals(context.ActualCorrelationId.ToString(),
                           context.ExpectedCorrelationId,
                           StringComparison.InvariantCultureIgnoreCase);
    }
}

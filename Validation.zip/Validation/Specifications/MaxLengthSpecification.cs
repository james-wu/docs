﻿using System;
using System.Linq.Expressions;
using Validation.Models;

namespace Validation.Specifications
{
    public class MaxLengthSpecification : RuleSpecification<MaxLengthContext>
    {
        public MaxLengthSpecification(MaxLengthContext ruleDefinitionContext) : base(ruleDefinitionContext) { }
        public override Expression<Func<MaxLengthContext, bool>> IsSatisfiedBy => maxLengthContext => IsSuccess(maxLengthContext);

        private static bool IsSuccess(MaxLengthContext context)
        {
            if (context.ColumnValue == null || context.MaxLength == -1)
            {
                return true;
            }

            return context.ColumnValue.Length <= context.MaxLength;
        }
    }
}
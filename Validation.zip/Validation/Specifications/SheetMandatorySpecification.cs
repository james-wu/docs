﻿using System;
using System.Linq.Expressions;
using Validation.Models;

namespace Validation.Specifications
{
    public class SheetMandatorySpecification: RuleSpecification<SheetMandatory>
    {
        public SheetMandatorySpecification(SheetMandatory ruleDefinitionContext) : base(ruleDefinitionContext)
        {
        }

        public override Expression<Func<SheetMandatory, bool>> IsSatisfiedBy => 
            sheet => sheet.DataRowCount > 0 && sheet.IsDirty;
    }
}

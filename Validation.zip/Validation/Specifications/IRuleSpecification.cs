﻿using System;
using System.Linq.Expressions;
using Validation.Models;

namespace Validation.Specifications
{
    public interface IRuleSpecification<TContext> where TContext : RuleDefinitionContext
    {
        Expression<Func<TContext, bool>> IsSatisfiedBy { get; }

        bool IsValid();

        string Message { get; }
    }
}

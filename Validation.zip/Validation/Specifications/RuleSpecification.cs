﻿using System;
using System.Linq.Expressions;
using Validation.Models;

namespace Validation.Specifications
{
    public abstract class RuleSpecification<TContext> : IRuleSpecification<TContext> where TContext: RuleDefinitionContext
    {
        public readonly TContext RuleDefinitionContext;

        protected RuleSpecification(TContext ruleDefinitionContext)
        {
            RuleDefinitionContext = ruleDefinitionContext;
        }

        public abstract Expression<Func<TContext, bool>> IsSatisfiedBy { get; }

        public ValidationError Validate()
        {
            Func<TContext, bool> predicate = IsSatisfiedBy.Compile();
            var isSatisfied = predicate(RuleDefinitionContext);

            return isSatisfied
                ? new ValidationError()
                : new ValidationError(RuleDefinitionContext.RuleDefinition.ErrorCode, RuleDefinitionContext.Key, Message);
        }

        public bool IsValid()
        {
            var predicate = IsSatisfiedBy.Compile();
            return predicate(RuleDefinitionContext);
        }

        public string Message =>
            RuleDefinitionContext.IsCombinedMessage
                ? $"{RuleDefinitionContext.RuleDefinition.ErrorCode}: {RuleDefinitionContext.RuleDefinition.Message}"
                : RuleDefinitionContext.RuleDefinition.Message;

        public string ErrorCode => RuleDefinitionContext.RuleDefinition.ErrorCode;
    }
}
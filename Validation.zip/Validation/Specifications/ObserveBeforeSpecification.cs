﻿using System;
using System.Linq.Expressions;
using Validation.Models;

namespace Validation.Specifications
{
    public class ObserveBeforeSpecification : RuleSpecification<ObserveBeforeContext>
    {
        public ObserveBeforeSpecification(ObserveBeforeContext ruleDefinitionContext) : base(ruleDefinitionContext) 
        {}

        public override Expression<Func<ObserveBeforeContext, bool>> IsSatisfiedBy => observeBeforeContext => IsSuccess(observeBeforeContext);

        private bool IsSuccess(ObserveBeforeContext context)
        {            
            if(context.ObserveGroupDictionary.ContainsKey(context.KeyToWatch))
            {
                return false;
            }

            context.ObserveGroupDictionary.TryAdd(context.KeyToWatch, context.KeyToWatch);
            return true;            
        }
    }
}



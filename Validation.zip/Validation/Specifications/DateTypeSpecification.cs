﻿using System;
using System.Globalization;
using System.Linq.Expressions;
using Validation.Models;

namespace Validation.Specifications
{
    public class DateTypeSpecification : RuleSpecification<TypeContext>
    {
        public DateTypeSpecification(TypeContext ruleDefinitionContext) : base(ruleDefinitionContext) { }
        public override Expression<Func<TypeContext, bool>> IsSatisfiedBy => typeContext => IsSuccess(typeContext);

        private static bool IsSuccess(TypeContext context)
        {
            if (string.IsNullOrEmpty(context.ColumnValue))
                return true;

            //We allow both mm and MM in the templates to represent month, since this is a Date validator specification, we will always convert both versions to MM
            var dateFormat = context.TypingDefinition.ContextHint?.Replace("mm", "MM");

            var canParseDate = DateTime.TryParseExact(
                context.ColumnValue,
                dateFormat,
                CultureInfo.InvariantCulture,
                DateTimeStyles.None, 
                out DateTime dateToVerify);
            return canParseDate;
        }


    }
}

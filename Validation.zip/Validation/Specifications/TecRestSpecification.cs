﻿using System;
using System.Linq;
using System.Linq.Expressions;
using Newtonsoft.Json;
using Validation.Models;

namespace Validation.Specifications
{
    public class TecRestSpecification : RuleSpecification<TecRestContext>
    {
        public TecRestSpecification(TecRestContext ruleDefinitionContext) : base(ruleDefinitionContext) { }

        public override Expression<Func<TecRestContext, bool>> IsSatisfiedBy => tecRestContext => IsSuccess(tecRestContext);

        private bool IsSuccess(TecRestContext context)
        {            
            if (context.ApiResponse.HttpStatusCode != System.Net.HttpStatusCode.OK)
                return false;

            System.Collections.Generic.List<object> content;
            try
            {
                content = JsonConvert.DeserializeObject<System.Collections.Generic.List<object>>(context.ApiResponse.Content);
            }
            catch 
            {
                //If exception thrown when deserializing content, treat as no content
                content = new System.Collections.Generic.List<object>();
            }

            return content.Any();
         }

    }
}
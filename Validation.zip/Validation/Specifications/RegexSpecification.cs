﻿using System;
using System.Linq.Expressions;
using System.Text.RegularExpressions;
using Validation.Models;

namespace Validation.Specifications
{
    public class RegexSpecification: RuleSpecification<RegexContext>
    {
        public RegexSpecification(RegexContext ruleDefinitionContext) : base(ruleDefinitionContext) { }
        public override Expression<Func<RegexContext, bool>> IsSatisfiedBy => regexContext => IsSuccess(regexContext);

        private static bool IsSuccess(RegexContext context)
        {
            if (context.ColumnValue == null)
            {
                return true;
            }

            var regex = new Regex(context.Pattern);
            var match = regex.Match(context.ColumnValue);
            return match.Success;
        }
    }
}
﻿using System;
using System.Globalization;
using System.Linq.Expressions;
using Validation.Models;

namespace Validation.Specifications
{
    public class AgeRangeAcceptableSpecification : RuleSpecification<AgeRangeAcceptableContext>
    {
        public AgeRangeAcceptableSpecification(AgeRangeAcceptableContext ruleDefinitionContext) : base(ruleDefinitionContext) { }
        public override Expression<Func<AgeRangeAcceptableContext, bool>> IsSatisfiedBy => ageRangeAcceptableContext => IsSuccess(ageRangeAcceptableContext);

        private static bool IsSuccess(AgeRangeAcceptableContext context)
        {
            // Going by current HAXE rule, if is an invalid date, or invalid context, we return false
            var canParseDate = DateTime.TryParseExact(context.ColumnValue, context.DateFormat, CultureInfo.InvariantCulture, System.Globalization.DateTimeStyles.None, out DateTime dateToVerify);            
            if (context.Min == -1 || context.Max == -1 || !canParseDate)
                return false;

            var age = DateTime.UtcNow.Year - dateToVerify.Year;
            return age >= context.Min && age <= context.Max;

        }
    }
}
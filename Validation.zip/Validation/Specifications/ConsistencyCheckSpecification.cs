﻿using System;
using System.Linq.Expressions;
using Validation.Models;

namespace Validation.Specifications
{
    public class ConsistencyCheckSpecification: RuleSpecification<ConsistencyCheckContext>
    {
        public ConsistencyCheckSpecification(ConsistencyCheckContext ruleDefinitionContext) : base(ruleDefinitionContext)
        { }

        public override Expression<Func<ConsistencyCheckContext, bool>> IsSatisfiedBy => consistencyCheckContext => IsSuccess(consistencyCheckContext);

        private bool IsSuccess(ConsistencyCheckContext context)
        {
            //If no context is given always return true as per current HAXE specification
            if (string.IsNullOrEmpty(context.ColumnsToObserve))
                return true;

            if (context.ConsistencyCheckGroupDictionary.ContainsKey(context.KeyToWatch.Key))
            {
                // there is already a record with this combo - only return true if they are the same
                return string.Compare(context.ConsistencyCheckGroupDictionary[context.KeyToWatch.Key], context.KeyToWatch.Value, true) == 0;                
            }

            context.ConsistencyCheckGroupDictionary.TryAdd(context.KeyToWatch.Key, context.KeyToWatch.Value);
            return true;
        }
    }
}



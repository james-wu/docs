﻿using System;
using System.Linq.Expressions;
using Validation.Models;

namespace Validation.Specifications
{
    public class MandatorySpecification : RuleSpecification<MandatoryContext>
    {
        public MandatorySpecification(MandatoryContext ruleDefinitionContext) : base(ruleDefinitionContext) { }
        public override Expression<Func<MandatoryContext, bool>> IsSatisfiedBy => mandatoryContext => IsSuccess(mandatoryContext);

        private static bool IsSuccess(MandatoryContext context)
        {
            return !string.IsNullOrEmpty(context.ColumnValue);
        }
    }
}
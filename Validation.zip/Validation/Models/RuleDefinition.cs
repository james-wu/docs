﻿namespace Validation.Models
{
    public class RuleDefinition
    {
        public string ErrorCode { get; }

        public string Message { get; }

        public object Context { get; }

        public RuleDefinition(string errorCode, string message, object context = null)
        {
            ErrorCode = errorCode;
            Message = message;
            Context = context;
        }
    }
}

﻿using System;

namespace Validation.Models
{
    public class RuleIdentifier : IEquatable<RuleIdentifier>
    {
        public string Name { get; set; }
        public string Code { get; set; }

        public bool Equals(RuleIdentifier other)
        {
            if (other == null)
            {
                return false;
            }

            return other.Name == this.Name && other.Code == this.Code;
        }

        public override bool Equals(object obj) => Equals(obj as RuleIdentifier);
        public override int GetHashCode() => (Name, Code).GetHashCode();
    }
}
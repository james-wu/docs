﻿using System.Collections.Generic;

namespace Validation.Models
{
    public class ValidationResponse
    {
        public IEnumerable<ValidationError> Errors { get; }

        public ValidationResponse(IEnumerable<ValidationError> errors)
        {
            Errors = errors;
        }

        public ValidationResponse()
        {
            Errors = new System.Collections.Generic.List<ValidationError>();
        }
    }
}

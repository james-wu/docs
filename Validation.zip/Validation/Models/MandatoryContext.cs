﻿namespace Validation.Models
{
    public class MandatoryContext:RuleDefinitionContext
    {
        public MandatoryContext(RuleDefinition ruleDefinition,
            string columnValue,
            string columnName) : base(ruleDefinition, columnValue, columnName){}
    }
}

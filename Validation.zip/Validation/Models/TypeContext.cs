﻿using TEC.CommonServices.Shared.Metadata;

namespace Validation.Models
{
    public class TypeContext: RuleDefinitionContext
    {
        public TypingDefinition TypingDefinition { get; set; }
        public TypeContext(
            RuleDefinition ruleDefinition,
            string columnValue,
            string columnName,
            TypingDefinition typingDefinition) : base(ruleDefinition, columnValue, columnName)
        {
            TypingDefinition = typingDefinition;
        }
    }
}

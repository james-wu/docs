﻿namespace Validation.Models
{
    public class CachedValidationContext
    {
        public string ColumnValue { get; set; }
        public System.Collections.Generic.List<ValidationError> Errors { get; set; }
    }
}

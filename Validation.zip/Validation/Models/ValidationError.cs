﻿namespace Validation.Models
{
    public class ValidationError
    {
        public ValidationError(string errorErrorCode, string key, string message = null)
        {
            ErrorCode = errorErrorCode;
            Message = message;
            Key = key;
            IsValid = message == null;
        }

        public ValidationError()
        {
            
        }

        public ValidationError(string key, string message, bool isWarning, string errorCode, string value)
        {
            Message = message;
            IsWarning = isWarning;
            ErrorCode = errorCode;
            Value = value;
            Key = key;
        }

        public string Message { get; set; }
        public bool IsValid { get; set; }
        public bool IsWarning { get; set; }
        public string ErrorCode { get; set; }
        public string Value { get; set; }
        public string Key { get; set; }
        
    }
}

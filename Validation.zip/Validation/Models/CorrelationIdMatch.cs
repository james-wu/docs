﻿namespace Validation.Models
{
    /// <summary>
    /// Naming convention over configuration, class name needs to match the rule name defined int the .WellKnownNames metadata
    /// </summary>
    public class CorrelationIdMatch : RuleDefinitionContext
    {
        public string ExpectedCorrelationId { get; }
        public object ActualCorrelationId { get; }

        public CorrelationIdMatch(RuleDefinition ruleDefinition,
            string expectedCorrelationId,
            object actualCorrelationId)
            : base(ruleDefinition, "Reference", true)
        {
            ExpectedCorrelationId = expectedCorrelationId;
            ActualCorrelationId = actualCorrelationId;
        }
    }
}

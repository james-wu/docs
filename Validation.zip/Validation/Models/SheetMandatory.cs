﻿namespace Validation.Models
{
    public class SheetMandatory: RuleDefinitionContext
    {
        public int DataRowCount { get; }
        public bool IsDirty { get; }

        public SheetMandatory(RuleDefinition ruleDefinition, int dataRowCount, bool isDirty) 
            : base(ruleDefinition, "Report", true)
        {
            DataRowCount = dataRowCount;
            IsDirty = isDirty;
        }
    }
}

﻿namespace Validation.Models
{
    public class TecRestContext : RuleDefinitionContext
    {
        public HttpApiResponse ApiResponse { get; set; }
        
        public TecRestContext(RuleDefinition ruleDefinition,
            string columnValue,
            HttpApiResponse apiResponse,            
            string columnName) : base(ruleDefinition, columnValue, columnName)
        {
            ApiResponse = apiResponse;
        }        
    }
}

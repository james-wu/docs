﻿using System.Collections.Concurrent;
using System.Collections.Generic;

namespace Validation.Models
{
    public class ValidationResult
    {
        public IEnumerable<ValidationError> Errors { get; set; }
        public KeyValuePair<string, object> ExtractedProperties { get; set; } = new KeyValuePair<string, object>();
    }
}

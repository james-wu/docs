﻿using System.Net;

namespace Validation.Models
{
    public class HttpApiResponse
    {
        public System.Net.HttpStatusCode HttpStatusCode { get; }
        public string Content { get; }

        public HttpApiResponse(HttpStatusCode httpStatusCode, string content)
        {
            HttpStatusCode = httpStatusCode;
            Content = content;
        }
    }
}

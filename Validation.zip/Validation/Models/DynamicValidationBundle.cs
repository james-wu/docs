﻿using TEC.CommonServices.Shared.Abstracts;

namespace Validation.Models
{
    public class DynamicValidationBundle : BaseValidationBundle { }
}

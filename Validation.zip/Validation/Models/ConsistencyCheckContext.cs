﻿using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;

namespace Validation.Models
{
    public class ConsistencyCheckContext : RuleDefinitionContext
    {
        public ConcurrentDictionary<string, string> ConsistencyCheckGroupDictionary { get; set; }
        public KeyValuePair<string,string> KeyToWatch { get; set; }
        public string ColumnsToObserve { get; set; }

        public ConsistencyCheckContext(RuleDefinition ruleDefinition,
            string columnValue,
            string columnsToObserve,
            ConcurrentDictionary<string, string> consistencyCheckGroupDictionary,
            Dictionary<string, object> columnValuesDictionary,
            string columnName) : base(ruleDefinition, columnValue, columnName)
        {
            ConsistencyCheckGroupDictionary = consistencyCheckGroupDictionary;
            ColumnsToObserve = columnsToObserve;
            KeyToWatch = SetKeyToWatch(columnName, columnValue, columnsToObserve, columnValuesDictionary);
        }

        private KeyValuePair<string,string> SetKeyToWatch(string columnName, string columnValue, string columnsToObserve, Dictionary<string, object> columnValuesDictionary)
        {
            var key = string.Concat("consistencycheck:", columnName, ">", columnValue);
            var value = string.Empty;

            var columnsToObserveSplit = columnsToObserve.Split(',').OrderBy(s => s);
            foreach (var columnToObserve in columnsToObserveSplit)
            {
                key = string.Concat(key, ":", columnToObserve);
                value = string.Concat(value, ":", columnToObserve, ">",
                    columnValuesDictionary.ContainsKey(columnToObserve)
                        ? columnValuesDictionary[columnToObserve]?.ToString()
                        : "");
            }

            return new KeyValuePair<string, string>(key, value);
        }
    }
}

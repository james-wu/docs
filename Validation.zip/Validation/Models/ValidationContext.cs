﻿using System.Collections.Concurrent;
using System.Collections.Generic;
using TEC.CommonServices.Shared.Metadata;

namespace Validation.Models {
    public class ValidationContext
    {
        public Dictionary<string, object> ColumnValuesDictionary { get; }
        public TEC.CommonServices.Shared.Metadata.RuleDefinition RuleDefinition { get; }
        public IEnumerable<KeyValuePair<string, string>> OptionValuesDictionary { get; }
        public string ColumnName { get; }

        public ConcurrentDictionary<string, string> SheetDictionary { get; set; }

        public TypingDefinition TypingDefinition { get; }

        public ValidationContext(Dictionary<string, object> columnValuesDictionary,
            TEC.CommonServices.Shared.Metadata.RuleDefinition ruleDefinition,
            IEnumerable<KeyValuePair<string, string>> optionValuesDictionary,
            string columnName,
            ConcurrentDictionary<string, string> sheetDictionary,
            TypingDefinition typingDefinition
        )
        {
            ColumnValuesDictionary = columnValuesDictionary;
            RuleDefinition = ruleDefinition;
            OptionValuesDictionary = optionValuesDictionary;
            ColumnName = columnName;
            SheetDictionary = sheetDictionary;
            TypingDefinition = typingDefinition;
        }

        public ValidationContext(Dictionary<string, object> columnValuesDictionary,
            TypingDefinition typingDefinition,
            IEnumerable<KeyValuePair<string, string>> optionValuesDictionary,
            string columnName
            )
        {
            ColumnValuesDictionary = columnValuesDictionary;
            OptionValuesDictionary = optionValuesDictionary;
            ColumnName = columnName;
            TypingDefinition = typingDefinition;
        }
    }
}

﻿namespace Validation.Models
{
    public class AgeRangeAcceptableContext: RuleDefinitionContext
    {
        public int Min { get; }
        public int Max { get; }
        public string DateFormat { get; }
        public AgeRangeAcceptableContext(RuleDefinition ruleDefinition,
            string columnValue,
            string dateFormat,
            string ranges,
            string columnName) : base(ruleDefinition, columnValue, columnName)
        {
            DateFormat = dateFormat.Replace("mm","MM");
            var splitRanges = ranges.Split(',');
            if(splitRanges.Length != 2)
            {
                Min = -1;
                Max = -1;
            }
            else
            {
                Min = GetParameterValue(splitRanges[0]);
                Max = GetParameterValue(splitRanges[1]);
            }
        }

        private int GetParameterValue(string parameter)
        {
            var paramValueParseable = int.TryParse(parameter.Substring(parameter.IndexOf("=") + 1), out int paramIntValue);
            return paramValueParseable ? paramIntValue : -1; 
        }
    }
}

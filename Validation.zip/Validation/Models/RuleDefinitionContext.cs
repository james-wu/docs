﻿namespace Validation.Models
{
    public class RuleDefinitionContext
    {
        public RuleDefinitionContext(RuleDefinition ruleDefinition, string key, bool isCombinedMessage = false)
        {
            RuleDefinition = ruleDefinition;
            IsCombinedMessage = isCombinedMessage;
            Key = key;
        }

        public RuleDefinitionContext(
            RuleDefinition ruleDefinition,
            string columnValue,
            string columnName,
            bool isCombinedMessage = false)
            : this(ruleDefinition, columnName, isCombinedMessage)
        {
            ColumnValue = columnValue;
        }

        public RuleDefinition RuleDefinition { get; }
        public bool IsCombinedMessage { get; }
        public string ColumnValue { get; }
        public string Key { get; }

    }
}
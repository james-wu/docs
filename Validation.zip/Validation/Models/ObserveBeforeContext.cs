﻿using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;

namespace Validation.Models
{
    public class ObserveBeforeContext : RuleDefinitionContext
    {
        public ConcurrentDictionary<string, string> ObserveGroupDictionary { get; set; }
        public string KeyToWatch { get; set; }

        public ObserveBeforeContext(RuleDefinition ruleDefinition,
            string columnValue,
            string columnsToObserve,
            ConcurrentDictionary<string, string> observeGroupDictionary,
            Dictionary<string, object> columnValuesDictionary,
            string columnName) : base(ruleDefinition, columnValue, columnName)
        {
            ObserveGroupDictionary = observeGroupDictionary;
            KeyToWatch = SetKeyToWatch(columnName, columnValue, columnsToObserve, columnValuesDictionary);
        }

        private string SetKeyToWatch(string columnName, string columnValue, string columnsToObserve, Dictionary<string, object> columnValuesDictionary)
        {         
            var key = ConcatToKey("observe", columnName, columnValue);
            if (!string.IsNullOrEmpty(columnsToObserve))
            {
                var columnsToObserveSplit = columnsToObserve.Split(',').OrderBy(s=>s);
                foreach (var columnToObserve in columnsToObserveSplit)
                {
                    var columnToObserveValue = columnValuesDictionary.ContainsKey(columnToObserve)
                                                                        ? columnValuesDictionary[columnToObserve]?.ToString()
                                                                        : "";
                            
                    key = ConcatToKey(key, columnToObserve, columnToObserveValue);
                }
            }
            return key.ToLower();
        }

        private string ConcatToKey(string key, string columnName, string columnValue)
        {
            return string.Concat(key, ":", columnName, ">", columnValue);
        }
    }
}

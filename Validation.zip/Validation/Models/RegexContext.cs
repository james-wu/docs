﻿namespace Validation.Models
{
    public class RegexContext : RuleDefinitionContext
    {
        public string Pattern { get; }
        public RegexContext(RuleDefinition ruleDefinition,
            string columnValue,
            string pattern,
            string columnName) : base(ruleDefinition, columnValue, columnName)
        {
            Pattern = pattern;
        }
    }
}

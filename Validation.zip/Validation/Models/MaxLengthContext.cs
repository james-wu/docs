﻿namespace Validation.Models
{
    public class MaxLengthContext : RuleDefinitionContext
    {
        public int MaxLength { get; }
        public MaxLengthContext(RuleDefinition ruleDefinition,
            string columnValue,
            int maxLength,
            string columnName) : base(ruleDefinition, columnValue, columnName)
        {
            MaxLength = maxLength;
        }
    }
}

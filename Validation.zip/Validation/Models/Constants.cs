﻿namespace Validation.Models
{
    public static class Constants
    {
        public static class RuleName
        {
            public const string Mandatory = "mandatory";
            public const string AgeRangeAcceptable = "ageRangeAcceptable";
            public const string ConsistencyCheck = "consistencyCheck";
            public const string Date = "Date";
            public const string Dynamic = "dynamic";
            public const string Ignore = "ignore";
            public const string MaxLength = "maxLength";
            public const string ObservedBefore = "observedBefore";
            public const string TecRest = "tecREST";
            public const string Regex = "regex";
            public const string InterDependence = "interDependence";
        }

        public static class ExpressionName
        {
            public const string OneOf = "OneOf";
        }
    }
}
﻿using System.Collections.Generic;
using System.Linq;
using Validation.Models;
using Validation.Specifications;

namespace Validation.Validators
{
    public class Validator<TContext> where TContext: RuleDefinitionContext
    {
        private readonly System.Collections.Generic.List<RuleSpecification<TContext>> _specifications;
        
        public Validator(RuleSpecification<TContext> specification)
        {
            _specifications = new System.Collections.Generic.List<RuleSpecification<TContext>>
            {
                specification
            };
        }

        public virtual IEnumerable<ValidationError> Validate()
        {
            return _specifications.Where(spec => !spec.IsValid())
                .Select(err => new ValidationError(
                err.RuleDefinitionContext.Key,
                err.Message,
                false,
                err.ErrorCode,
                err.RuleDefinitionContext.ColumnValue)).ToList();
        }
    }
}

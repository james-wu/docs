﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Validation.Models;
using Validation.Specifications;
using Validation.Validators;

namespace Validation.Services {
    public class DateTypingService : IRuleValidationService
    {
        public string RuleName => Constants.RuleName.Date;
        public async Task<ValidationResult> ValidateAsync(ValidationContext context)
        {
            var column = context.ColumnValuesDictionary[context.ColumnName];
            var inputValue = column?.ToString();

            var typeContext = new TypeContext(
                new RuleDefinition(context.TypingDefinition.ErrorCode,
                    context.TypingDefinition.Message,
                    context.TypingDefinition.ContextHint),
                inputValue, context.ColumnName, context.TypingDefinition);

            var validator = new Validator<TypeContext>(new DateTypeSpecification(typeContext));

            var validationErrors = validator.Validate();

            return await Task.FromResult(new ValidationResult {
                Errors = validationErrors
            });

        }
    }
}

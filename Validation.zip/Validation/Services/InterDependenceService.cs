﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Validation.Models;

namespace Validation.Services {
    public class InterDependenceService: IRuleValidationService
    {
        public string RuleName => Constants.RuleName.InterDependence;
        public async Task<ValidationResult> ValidateAsync(ValidationContext context)
        {
            return await Task.FromResult(new ValidationResult {
                Errors = new System.Collections.Generic.List<ValidationError>(0)
            });

        }
    }
}
﻿using System.Collections;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json.Linq;
using TEC.CommonServices.Discovery;
using Validation.Models;
using Validation.Specifications;
using Validation.Validators;

namespace Validation.Services {
    public class TecRESTService: IRuleValidationService
    {
        // We decided to put the constants here for now as this class will be moved 
        private const string ReferenceAPIServiceName = "APIs:ReferenceServiceName";
        private const string CurrentPlaceholder = "{current}";
        private const string DocumentPlaceholder = "{{Document:{0}}}";

        private readonly IHttpClientFactory _httpClientFactory;
        private readonly IDiscoveryService _discoveryService;
        private readonly IConfiguration _config;

        public string RuleName => Constants.RuleName.TecRest;
        
        public TecRESTService(IHttpClientFactory httpClientFactory, IDiscoveryService discoveryService, IConfiguration config)
        {
            _httpClientFactory = httpClientFactory;
            _discoveryService = discoveryService;
            _config = config;
        }

        public async Task<ValidationResult> ValidateAsync(ValidationContext context)
        {
            var column = context.ColumnValuesDictionary[context.ColumnName];
            var inputValue = column?.ToString();

            // no input to validate - return true, as per current business rule
            if (string.IsNullOrEmpty(inputValue))
            {
                return await Task.FromResult(new ValidationResult
                {
                    Errors = new System.Collections.Generic.List<ValidationError>(0)
                });
            }

            var apiResponse = await GetApiResponse(inputValue, context);
            var tecRestContext = new TecRestContext(
                new RuleDefinition(context.RuleDefinition.ErrorCode,
                    context.RuleDefinition.Message,
                    context.RuleDefinition.Context),
                inputValue,
                apiResponse,
                context.ColumnName
            );

            var validator = new Validator<TecRestContext>(new TecRestSpecification(tecRestContext));
            var validationErrors = validator.Validate();

            var referenceDataProperties = new KeyValuePair<string, object>();
            if (!validationErrors.Any())
            {
                referenceDataProperties = ExtractReferenceDataProperties(context, apiResponse);
            }            

            return await Task.FromResult(new ValidationResult
            {
                Errors = validationErrors,
                ExtractedProperties = referenceDataProperties
            });

        }

        private static KeyValuePair<string, object> ExtractReferenceDataProperties(ValidationContext context,
            HttpApiResponse apiResponse)
        {
            var apiResponseContent = JArray.Parse(apiResponse.Content);

            if (!apiResponseContent.Any() || string.IsNullOrEmpty(context.RuleDefinition.AssignTo) ||
                string.IsNullOrEmpty(context.RuleDefinition.AssignFrom))
            {
                return new KeyValuePair<string, object>();
            }

            var extractedValue = apiResponseContent[0][context.RuleDefinition.AssignFrom];
            return new KeyValuePair<string, object>(context.RuleDefinition.AssignTo, extractedValue);

        }

        private async Task<HttpApiResponse> GetApiResponse(string inputValue, ValidationContext context)
        {
            var augmentedOptionValuesDictionary = AugmentOptionValuesDictionaryWithColumnValuePairs(context.ColumnValuesDictionary, context.OptionValuesDictionary);
            var referenceApiServiceName = _config.GetValue<string>(ReferenceAPIServiceName);
            var baseUrl = (await _discoveryService.Single(referenceApiServiceName)).Url;
            var fullUrl = string.Concat(baseUrl, SubstituteUrlParameters(context.RuleDefinition.Context, augmentedOptionValuesDictionary, inputValue));

            var httpClient = _httpClientFactory.CreateClient();
            var apiResponse = await httpClient.GetAsync(fullUrl);


            return new HttpApiResponse(apiResponse.StatusCode, await apiResponse.Content.ReadAsStringAsync());
        }

        private string SubstituteUrlParameters(string url, IEnumerable<KeyValuePair<string, string>> optionValuesDictionary, string columnValue)
        {
            url = url.Replace(CurrentPlaceholder, HttpUtility.UrlEncode(columnValue));
            foreach (var keyValuePair in optionValuesDictionary)
            {
                url = url.Replace(keyValuePair.Key, HttpUtility.UrlEncode(keyValuePair.Value));
            }
            return url;
        }

        private IEnumerable<KeyValuePair<string, string>> AugmentOptionValuesDictionaryWithColumnValuePairs(Dictionary<string, object> columnValuesDictionary, IEnumerable<KeyValuePair<string, string>> optionValuesDictionary)
        {
            var columnValuePairs = columnValuesDictionary.Select(c => new KeyValuePair<string, string>(string.Format(DocumentPlaceholder, c.Key), c.Value?.ToString()));            
            var augmentedDictionary = Enumerable.Concat(optionValuesDictionary ?? new List<KeyValuePair<string, string>>(), columnValuePairs);
            
            return augmentedDictionary;
        }
    }
}
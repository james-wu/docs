﻿using System.Collections.Generic;

namespace Validation.Services
{
    public interface IExpressionValidationService
    {
        string ExpressionName{ get; }
        bool Validate(Dictionary<string, object> columnValuesDictionary, string expression);
    }
}
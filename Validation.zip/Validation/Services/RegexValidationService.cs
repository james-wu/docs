﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Validation.Models;
using Validation.Specifications;
using Validation.Validators;

namespace Validation.Services
{
    public class RegexValidationService : IRuleValidationService
    {
        public string RuleName => Constants.RuleName.Regex;

        public async Task<ValidationResult> ValidateAsync(ValidationContext context)
        {
            var column = context.ColumnValuesDictionary[context.ColumnName];

            var inputValue = column?.ToString();

            var regexContext = new RegexContext(
                new Models.RuleDefinition(context.RuleDefinition.ErrorCode,
                    context.RuleDefinition.Message,
                    context.RuleDefinition.Context),
                inputValue,
                context.RuleDefinition.Context, context.ColumnName);

            var validator = new Validator<RegexContext>(new RegexSpecification(regexContext));

            var validationErrors = validator.Validate();

            return await Task.FromResult(new ValidationResult {
                Errors = validationErrors
            });
        }
    }
}

﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Validation.Models;
using Validation.Specifications;
using Validation.Validators;

namespace Validation.Services {
    public class ConsistencyCheckService: IRuleValidationService
    {
        public string RuleName => Constants.RuleName.ConsistencyCheck;
        public async Task<ValidationResult> ValidateAsync(ValidationContext context)
        {
            var column = context.ColumnValuesDictionary[context.ColumnName];
            var inputValue = column?.ToString();

            var consistencyCheckContext = new ConsistencyCheckContext(
                new Models.RuleDefinition(context.RuleDefinition.ErrorCode,
                    context.RuleDefinition.Message,
                    context.RuleDefinition.Context),
                    inputValue,
                    context.RuleDefinition.Context,
                    context.SheetDictionary,
                    context.ColumnValuesDictionary,
                    context.ColumnName
                );

            var validator = new Validator<ConsistencyCheckContext>(new ConsistencyCheckSpecification(consistencyCheckContext));
            var validationErrors = validator.Validate();
            return await Task.FromResult(new ValidationResult {
                Errors = validationErrors
            });
        }
    }
}
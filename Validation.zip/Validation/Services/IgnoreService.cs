﻿using System.Threading.Tasks;
using Validation.Models;

namespace Validation.Services
{
    public class IgnoreService : IRuleValidationService
    {
        public string RuleName => Constants.RuleName.Ignore;
        public async Task<ValidationResult> ValidateAsync(ValidationContext context)
        {
            return await Task.FromResult(new ValidationResult {
                Errors = new System.Collections.Generic.List<ValidationError>(0)
            });
        }

    }
}
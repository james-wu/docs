﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Validation.Models;
using Validation.Specifications;
using Validation.Validators;

namespace Validation.Services {
    public class MandatoryService: IRuleValidationService
    {
        public string RuleName => Constants.RuleName.Mandatory;
        public async Task<ValidationResult> ValidateAsync(ValidationContext context)
        {            
            var column = context.ColumnValuesDictionary[context.ColumnName];
            var inputValue = column?.ToString();

            var mandatoryContext = new MandatoryContext(
                new RuleDefinition(context.RuleDefinition.ErrorCode,
                    context.RuleDefinition.Message,
                    context.RuleDefinition.Context),
                inputValue,context.ColumnName);

            var validator = new Validator<MandatoryContext>(new MandatorySpecification(mandatoryContext));

            var validationErrors = validator.Validate();

            return await Task.FromResult(new ValidationResult {
                Errors = validationErrors
            });
        }
    }
}
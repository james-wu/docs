﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Validation.Models;
using Validation.Specifications;
using Validation.Validators;

namespace Validation.Services {
    public class AgeRangeAcceptableService: IRuleValidationService
    {
        public string RuleName => Constants.RuleName.AgeRangeAcceptable;
        public async Task<ValidationResult> ValidateAsync(ValidationContext context)
        {
            var column = context.ColumnValuesDictionary[context.ColumnName];
            var inputValue = column?.ToString();
            var dateFormat = context.TypingDefinition?.ContextHint;

            var ageRangeAcceptableContext = new AgeRangeAcceptableContext(
                new RuleDefinition(context.RuleDefinition.ErrorCode,
                    context.RuleDefinition.Message,
                    context.RuleDefinition.Context),
                inputValue,
                dateFormat??"dd/MM/yyyy",
                context.RuleDefinition.Context,
                context.ColumnName);

            var validator = new Validator<AgeRangeAcceptableContext>(new AgeRangeAcceptableSpecification(ageRangeAcceptableContext));
            var validationErrors = validator.Validate();

            return await Task.FromResult(new ValidationResult
            {
                Errors = validationErrors
            });
        }
    }
}
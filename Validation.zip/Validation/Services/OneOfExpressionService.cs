﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using TEC.Infra;
using Validation.Models;

namespace Validation.Services
{
    public class OneOfExpressionService : IExpressionValidationService
    {
        public string ExpressionName => Constants.ExpressionName.OneOf;

        public bool Validate(Dictionary<string, object> columnValuesDictionary, string expression)
        {
            var validationData = ExtractExpressionData(expression);
            if (!string.IsNullOrEmpty(validationData))
            {
                var splitValidationData = validationData.Split(',');

                Assert.False<ArgumentException>(splitValidationData.Length <= 1,
                () => $"Cannot proceed, expression is is incomplete");

                var columnToCompare = splitValidationData.First();                
                var valueToCompare = columnValuesDictionary[columnToCompare]?.ToString();

                return splitValidationData.Skip(1).Any(d => d == valueToCompare);
            }

            return true;
        }


        private string ExtractExpressionData(string expression)
        {
            // extract values between the two brackets
            var regex = @"\(([^)]+)\)";
            var validationData = Regex.Match(expression, regex).Groups[1].Value;

            return validationData;
        }
    }
}

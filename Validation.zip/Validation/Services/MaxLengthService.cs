﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Validation.Models;
using Validation.Specifications;
using Validation.Validators;

namespace Validation.Services {
    public class MaxLengthService: IRuleValidationService
    {
        public string RuleName => Constants.RuleName.MaxLength;
        public async Task<ValidationResult> ValidateAsync(ValidationContext context)
        {
            var column = context.ColumnValuesDictionary[context.ColumnName];
            var inputValue = column?.ToString();
                        
            var maxLengthParsable = int.TryParse(context.RuleDefinition.Context, out int maxLength);

            var maxLengthContext = new MaxLengthContext(
                new RuleDefinition(context.RuleDefinition.ErrorCode,
                    context.RuleDefinition.Message,
                    context.RuleDefinition.Context),
                inputValue, maxLengthParsable?maxLength:-1, context.ColumnName);

            var validator = new Validator<MaxLengthContext>(new MaxLengthSpecification(maxLengthContext));

            var validationErrors = validator.Validate();

            return await Task.FromResult(new ValidationResult {
                Errors = validationErrors
            });

        }
    }
}
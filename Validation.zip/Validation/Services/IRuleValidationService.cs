﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Validation.Models;

namespace Validation.Services 
{
    public interface IRuleValidationService
    {
        /// <summary>
        /// Rule name defined in in the metadata WellKnownNames
        /// </summary>
        string RuleName { get; }
        Task<ValidationResult> ValidateAsync(ValidationContext context);
    }


    
}

﻿using System.Collections.Generic;
using TEC.CommonServices.Shared.Metadata;

namespace Validation.Metadata
{
    public interface IStructuralMetadata : IValidatableMetadata {

        List<string> SheetNames { get; }

        IEnumerable<int> DataStartRows { get; }

        IEnumerable<int> HeaderRows { get; }

        List<string> StopSequences { get; }

        IEnumerable<IField> Fields { get; }

        /// <summary>
        /// Determines if the template  has blank row
        /// </summary>
        List<BlankSequence> BlankSequences { get; }
    }

}

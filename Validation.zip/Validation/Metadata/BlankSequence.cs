﻿namespace Validation.Metadata
{
    public class BlankSequence 
    {
        public int Column { get; set; }
        public object Value { get; set; }
    }
}
